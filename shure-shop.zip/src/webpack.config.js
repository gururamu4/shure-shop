module.exports = {
    entry: "./src/main.ts"
}
