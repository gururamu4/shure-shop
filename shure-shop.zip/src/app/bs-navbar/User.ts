export interface User{
    id:number,
    email:string,
    imgUrl:string,
    username:string,
     password:string,
     isAdmin:boolean
  }