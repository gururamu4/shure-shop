export interface product
{ "id"?:string
    "createdDate": Date,
     "productId": string, 
     "productName": string,
      "price": number, 
      "imgSrc": string,
       "isLiked": boolean,
        "totalLikes": number, 
        "category": string
     }